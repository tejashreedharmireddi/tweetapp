export class UserTweets {
    public userName: string;
    public tweets:string;
    public imagename: string;
    public tweetDate:Date;
    public firstName: string;
    public lastName:string;
    public datecalculated:string;
    public likes:number;
}
