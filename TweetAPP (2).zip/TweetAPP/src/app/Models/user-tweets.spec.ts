import { UserTweets } from './user-tweets';

describe('UserTweets', () => {
  it('should create an instance', () => {
    expect(new UserTweets()).toBeTruthy();
  });
});
